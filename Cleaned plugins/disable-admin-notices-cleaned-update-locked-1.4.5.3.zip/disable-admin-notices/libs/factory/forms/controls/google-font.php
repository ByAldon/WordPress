<?php

	/**
	 * Dropdown List Control
	 *
	 * Main options:
	 *  name            => a name of the control
	 *  value           => a value to show in the control
	 *  default         => a default value of the control if the "value" option is not specified
	 *  items           => a callback to return items or an array of items to select
	 *
	 * @author Alex Kovalev <alex.kovalevv@gmail.com>
	 * @copyright (c) 2018, Webcraftic Ltd
	 *
	 * @package core
	 * @since 1.0.0
	 */
	class Wbcr_FactoryForms480_GoogleFontControl extends Wbcr_FactoryForms480_FontControl {

		public $type = 'google-font';
		const APIKEY = 'AIzaSyB-3vazYv7Q-5QZA04bmSKFrWcw_VhC40w';

		public function __construct($options, $form, $provider = null)
		{
			parent::__construct($options, $form, $provider);
			$this->addCssClass('factory-font');

			$option_google_font_data = array(
				'name' => $this->options['name'] . '__google_font_data',
				'cssClass' => 'factory-google-font-data'
			);

			$this->google_font_data = new Wbcr_FactoryForms480_HiddenControl($option_google_font_data, $form, $provider);
			$this->inner_controls[] = $this->google_font_data;
		}

		/**
		 * @return array|mixed
		 */
		public function getDefaultFonts()
		{

			$cache_fonts = get_transient('wbcr_factory_google_fonts');

			if( !empty($cache_fonts) ) {
				return $cache_fonts;
			}

			$google_fonts = $this->getGoogleFonts();

			$fonts = array(
				array('inherit', __('(use default website font)', 'wbcr_factory_forms_480'))
			);

			$fontsCommon = array(
				'group',
				__('Standard:', 'wbcr_factory_forms_480'),
				array(

					array('Arial, "Helvetica Neue", Helvetica, sans-serif', 'Arial'),
					array('"Helvetica Neue", Helvetica, Arial, sans-serif', 'Helvetica'),
					array('Tahoma, Verdana, Segoe, sans-serif', 'Tahoma'),
					array('Verdana, Geneva, sans-serif', 'Verdana'),

				)
			);

			$fontsGoogleFonts = array('group', __('Google Fonts:', 'wbcr_factory_forms_480'), array());

			if ( empty( $google_fonts ) || empty( $google_fonts->items ) || ! is_array( $google_fonts->items ) ) {
				$fonts[] = $fontsCommon;
				$fonts[] = $fontsGoogleFonts;

				set_transient('wbcr_factory_google_fonts', $fonts, 60 * 60 * 6);

				return $fonts;
			}

			foreach($google_fonts->items as $item) {

				$alt_font = $item->category;
				if( in_array($alt_font, array('handwriting', 'display')) ) {
					$alt_font = 'serif';
				}

				$listItem = array(
					'title' => $item->family,
					'value' => $item->family . ', ' . $item->category,
					'hint' => '<em>Google Font</em>',
					'data' => array(
						'google-font' => true,
						'family' => $item->family,
						'variants' => $item->variants,
						'subsets' => $item->subsets
					)
				);

				$fontsGoogleFonts[2][] = $listItem;
			}

			$fonts[] = $fontsCommon;
			$fonts[] = $fontsGoogleFonts;

			set_transient('wbcr_factory_google_fonts', $fonts, 60 * 60 * 6);

			return $fonts;
		}

		/**
		 * @return array|mixed|object
		 */
		protected function getGoogleFonts()
		{

			$body = get_transient('wbcr_factory_google_fonts_raw');
			if( !empty($body) ) {
				return $body;
			}

			$this->error = false;
			$this->defailed_error = false;

			// Remote Google Fonts fetching is disabled in the cleaned build.
			$body = (object) array( 'items' => array() );

			set_transient('wbcr_factory_google_fonts_raw', $body, 60 * 60 * 6);

			return $body;
		}

		public function afterControlsHtml()
		{
			?>
			<?php $this->google_font_data->html() ?>
		<?php
		}
	}
