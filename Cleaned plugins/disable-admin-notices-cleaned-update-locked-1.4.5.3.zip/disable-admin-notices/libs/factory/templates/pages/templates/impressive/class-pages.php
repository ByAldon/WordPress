<?php

namespace WBCR\Factory_Templates_134\Pages;

/**
 * Общий класс прослойка для страниц Clearfy и его компоннетов.
 * В этом классе добавляются общие ресурсы и элементы, необходимые для всех связанных плагинов.
 *
 * @author        Alex Kovalev <alex.kovalevv@gmail.com>, Github: https://github.com/alexkovalevv
 * @since         2.0.5
 */

// Exit if accessed directly
if( !defined('ABSPATH') ) {
	exit;
}

//global $ssssdfsfsdf;

/**
 * Class Wbcr_FactoryPages480_ImpressiveThemplate
 *
 * @method string getRatingWidget(array $args = []) - get widget content rating
 * @method string getDonateWidget() - get widget content donate
 * @method string getSubscribeWidget()
 * @method string getBusinessSuggetionWidget()
 */
class PageBase extends \WBCR\Factory_Templates_134\Impressive {

	/**
	 * {@inheritDoc}
	 *
	 * @since   2.0.5 - добавлен
	 * @var bool
	 */
	public $show_right_sidebar_in_options = true;

	/**
	 * {@inheritDoc}
	 *
	 * @since  2.0.5 - добавлен
	 * @var bool
	 */
	public $available_for_multisite = true;

	/**
	 * {@inheritDoc}
	 *
	 * @since  2.0.6 - добавлен
	 * @var bool
	 */
	public $internal = true;

	/**
	 * Show on the page a search form for search options of plugin?
	 *
	 * @since  2.2.0 - Added
	 * @var bool - true show, false hide
	 */
	public $show_search_options_form;

	/**
	 * @param \Wbcr_Factory480_Plugin $plugin
	 */
	public function __construct(\Wbcr_Factory480_Plugin $plugin)
	{
		parent::__construct($plugin);

		if( is_null($this->show_search_options_form) ) {
			$this->show_search_options_form = false;
			if( "options" === $this->type ) {
				$this->show_search_options_form = true;
			}
		}

		if( "options" === $this->type && "hide_my_wp" !== $this->id ) {
			$this->register_options_to_search();
		}

		add_action("wp_ajax_wbcr-clearfy-subscribe-for-{$this->plugin->getPluginName()}", [
			$this,
			'subsribe_widget_ajax_handler'
		]);
	}

	/**
	 * @param $name
	 * @param $arguments
	 *
	 * @return null|string
	 */
	public function __call($name, $arguments)
	{
		if( substr($name, 0, 3) == 'get' ) {
			$called_method_name = 'show' . substr($name, 3);
			if( method_exists($this, $called_method_name) ) {
				ob_start();

				$this->$called_method_name($arguments);
				$content = ob_get_contents();
				ob_end_clean();

				return $content;
			}
		}

		return null;
	}

	/**
	 * Requests assets (js and css) for the page.
	 *
	 * @param \Wbcr_Factory480_ScriptList $scripts
	 * @param \Wbcr_Factory480_StyleList $styles
	 *
	 * @return void
	 * @see Wbcr_FactoryPages480_AdminPage
	 *
	 */
	public function assets($scripts, $styles)
	{
		parent::assets($scripts, $styles);

		$this->styles->add(FACTORY_TEMPLATES_134_URL . '/assets/css/clearfy-base.css');

		// todo: вынести все общие скрипты и стили фреймворка, продумать совместимость с другими плагинами
		if( defined('WCL_PLUGIN_URL') ) {
			$this->styles->add(WCL_PLUGIN_URL . '/admin/assets/css/general.css');
		}

		$this->scripts->add(FACTORY_TEMPLATES_134_URL . '/assets/js/clearfy-widgets.js', [
			'jquery',
			'wfactory-480-core-general',
			'wbcr-factory-templates-134-global'
		], 'wbcr-factory-templates-134-widgets');

		// Script for search form on plugin options
		if( $this->show_search_options_form ) {
			$this->styles->add(FACTORY_TEMPLATES_134_URL . '/assets/css/libs/autocomplete.css');

			$this->scripts->add(FACTORY_TEMPLATES_134_URL . '/assets/js/libs/jquery.autocomplete.min.js');
			$this->scripts->add(FACTORY_TEMPLATES_134_URL . '/assets/js/clearfy-search-options.js');
		}

		/**
		 * Allows you to enqueue scripts to the internal pages of the plugin.
		 * $this->getResultId() - page id + plugin name = quick_start-wbcr_clearfy
		 *
		 * @since 2.0.5
		 */
		do_action('wbcr/clearfy/page_assets', $this->getResultId(), $scripts, $styles);
	}

	/**
	 * Регистрируем ajax обработчик для текущей страницы
	 *
	 * @since 2.0.7
	 */
	public function subsribe_widget_ajax_handler()
	{
		wbcr_factory_templates_134_subscribe($this->plugin);
	}

	/**
	 * @return \Wbcr_Factory480_Request
	 */
	public function request()
	{
		return $this->plugin->request;
	}

	/**
	 * @param      $option_name
	 * @param bool $default *
	 *
	 * @return mixed|void
	 * @since 2.0.5
	 *
	 */
	public function getPopulateOption($option_name, $default = false)
	{
		return $this->plugin->getPopulateOption($option_name, $default);
	}

	/**
	 * @param      $option_name
	 * @param bool $default
	 *
	 * @return mixed|void
	 */
	public function getOption($option_name, $default = false)
	{
		return $this->plugin->getOption($option_name, $default);
	}

	/**
	 * @param $option_name
	 * @param $value
	 *
	 * @return void
	 */
	public function updatePopulateOption($option_name, $value)
	{
		$this->plugin->updatePopulateOption($option_name, $value);
	}

	/**
	 * @param $option_name
	 * @param $value
	 *
	 * @return void
	 */
	public function updateOption($option_name, $value)
	{
		$this->plugin->updateOption($option_name, $value);
	}

	/**
	 * @param $option_name
	 *
	 * @return void
	 */
	public function deletePopulateOption($option_name)
	{
		$this->plugin->deletePopulateOption($option_name);
	}

	/**
	 * @param $option_name
	 *
	 * @return void
	 */
	public function deleteOption($option_name)
	{
		$this->plugin->deleteOption($option_name);
	}

	/**
	 * @param string $position
	 *
	 * @return mixed|void
	 */
	protected function getPageWidgets($position = 'bottom')
	{
		$widgets = [];

		if( $position == 'bottom' ) {
			$widgets['rating_widget'] = $this->getRatingWidget();
			//$widgets['donate_widget'] = $this->getDonateWidget();
		} else if( $position == 'right' ) {
			$widgets['business_suggetion'] = $this->getBusinessSuggetionWidget();
			if( $this->plugin->getPluginInfoAttr('subscribe_widget') && !$this->plugin->getPopulateOption('factory_clearfy_user_subsribed') ) {
				$widgets['subscribe'] = $this->getSubscribeWidget();
			}
			$widgets['rating_widget'] = $this->getRatingWidget();
		}

		/**
		 * @since 4.0.9 - является устаревшим
		 */
		$widgets = wbcr_factory_480_apply_filters_deprecated('wbcr_factory_pages_480_imppage_get_widgets', [
			$widgets,
			$position,
			$this->plugin,
			$this
		], '4.0.9', 'wbcr/factory/pages/impressive/widgets');

		/**
		 * @since 4.0.1 - добавлен
		 * @since 4.0.9 - изменено имя
		 */
		$widgets = apply_filters('wbcr/factory/pages/impressive/widgets', $widgets, $position, $this->plugin, $this);

		return $widgets;
	}

	/**
	 * Создает Html разметку виджета для рекламы премиум версии
	 *
	 * @author Alexander Kovalev <alex.kovalevv@gmail.com>
	 * @since  2.0.2
	 */
	public function showBusinessSuggetionWidget()
	{
		// Disabled in this cleaned custom build.
	}


	/**
	 * Создает html разметку виджета рейтинга
	 *
	 * @param array $args
	 *
	 * @since  2.0.0
	 *
	 * @author Alexander Kovalev <alex.kovalevv@gmail.com>
	 */
	public function showRatingWidget(array $args)
	{
		// Disabled in this cleaned custom build.
	}


	/**
	 * Создает html размету виджета доната
	 *
	 * @author Alexander Kovalev <alex.kovalevv@gmail.com>
	 * @since  2.0.0
	 */
	public function showDonateWidget()
	{
		// Disabled in this cleaned custom build.
	}


    public function showSubscribeWidget()
    {
        // Disabled in this cleaned custom build.
    }

	/**
	 * Registers page options in the options registry
	 *
	 * This will allow the user to search all the plugin options.
	 */
	public function register_options_to_search()
	{
		require_once FACTORY_TEMPLATES_134_DIR . '/includes/class-search-options.php';

		$options = $this->getPageOptions();
		$page_url = $this->getBaseUrl();
		$page_id = $this->getResultId();

		\WBCR\Factory_Templates_134\Search_Options::register_options($options, $page_url, $page_id);
	}

	/**
	 * Add search plugin options form to each option page
	 */
	public function printAllNotices()
	{
		parent::printAllNotices(); // TODO: Change the autogenerated stub

		if( !$this->show_search_options_form ) {
			return;
		}
		?>
		<div id="wbcr-factory-templates-134__search_options_form" class="wbcr-factory-templates-134__autocomplete-wrap">
			<label for="autocomplete" class="wbcr-factory-templates-134__autocomplete-label">
				<?php _e('Can\'t find the settings you need? Use the search by the plugin options:', 'wbcr_factory_templates_134'); ?>
			</label>
			<input type="text" placeholder="<?php _e('Enter the option name to search...', 'wbcr_factory_templates_134'); ?>" name="country" id="wbcr-factory-templates-134__autocomplete"/>

		</div>
		<?php
	}
}

