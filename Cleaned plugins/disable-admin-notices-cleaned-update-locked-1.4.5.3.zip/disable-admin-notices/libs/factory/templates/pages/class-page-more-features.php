<?php

namespace WBCR\Factory_Templates_134\Pages;

/**
 * The page Settings.
 *
 * @author        Alex Kovalev <alex.kovalevv@gmail.com>, Github: https://github.com/alexkovalevv
 * @since         1.0.1
 * @package       clearfy
 * @copyright (c) 2018, Webcraftic Ltd
 *
 */

// Exit if accessed directly
if( !defined('ABSPATH') ) {
	exit;
}


class MoreFeatures extends \WBCR\Factory_Templates_134\Impressive {

	/**
	 * {@inheritDoc}
	 *
	 * @var string
	 */
	public $id = "more_features";

	/**
	 * {@inheritDoc}
	 *
	 * @var string
	 */
	public $page_menu_dashicon = 'dashicons-star-filled wbcr-factory-orange-color';

	/**
	 * {@inheritDoc}
	 *
	 * @var string
	 */
	public $page_menu_position = 5;

	/**
	 * {@inheritDoc}
	 *
	 * @var string
	 */
	public $type = 'page';

	/**
	 * {@inheritDoc}
	 *
	 * @var bool
	 */
	public $available_for_multisite = true;

	/**
	 * {@inheritDoc}
	 *
	 * @since  2.0.6 - добавлен
	 * @var bool
	 */
	public $internal = true;

	public function __construct(\Wbcr_Factory480_Plugin $plugin)
	{
		$this->menu_title = __('More features (<b>free</b>)', 'wbcr_factory_templates_134');

		parent::__construct($plugin);

		$this->plugin = $plugin;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @return string
	 */
	public function getPageTitle()
	{
		return __('More features', 'wbcr_factory_templates_134');
	}

	/**
	 * {@inheritDoc}
	 *
	 * @return void
	 */
	public function showPageContent()
	{
		?>
		<div class="notice notice-info inline"><p><?php esc_html_e( 'Promotional content is disabled in this cleaned custom build.', 'wbcr_factory_templates_134' ); ?></p></div>
		<?php
	}

}

