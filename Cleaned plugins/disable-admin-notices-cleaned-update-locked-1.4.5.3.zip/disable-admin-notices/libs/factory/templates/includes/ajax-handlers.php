<?php
/**
 * Ajax handlers
 *
 * @author        Alex Kovalev <alex.kovalevv@gmail.com>, Github: https://github.com/alexkovalevv
 * @copyright (c) 2017 Webraftic Ltd
 * @version       1.0
 */

// Exit if accessed directly
if( !defined('ABSPATH') ) {
	exit;
}

/**
 * Обработчик ajax запросов для виджета подписки на новости
 *
 * @param Wbcr_Factory480_Plugin $plugin_instance
 *
 * @since 2.3.0
 *
 */
function wbcr_factory_templates_134_subscribe($plugin_instance)
{
	$plugin_name = $plugin_instance->request->post('plugin_name', null, true);

	if( ($plugin_instance->getPluginName() !== $plugin_name) || !$plugin_instance->current_user_can() ) {
		wp_die(-1, 403);
	}

	$email = $plugin_instance->request->post('email', null, true);

	check_admin_referer("clearfy_subscribe_for_{$plugin_name}");

	if( empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL) ) {
		wp_send_json_error(['error_message' => __('You did not send your email address or it is incorrect!', 'wbcr_factory_templates_134')]);
	}



	wp_send_json_error( [ 'error_message' => __( 'Subscriptions are disabled in this cleaned build.', 'wbcr_factory_templates_134' ) ] );

	die();
}
